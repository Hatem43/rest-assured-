package org.example;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

import java.util.List;
import java.util.concurrent.TimeUnit;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.head;


public class Restassured {

    final static String url="http://demo.guru99.com/V4/sinkministatement.php?CUSTOMER_ID=68195&PASSWORD=1234!&Account_No=1";

    public static void getResponse(){
        given().when().get(url).then().log()
                .all();
    }

    public static void getresponsebody(){
        given().when().get(url).then().log().body();
    }

    public static void getresponsestatus(){
        int statusCode=given()
                .queryParam("CUSTOMER_ID","68195")
                .queryParam("PASSWORD","1234")
                .queryParam("Account_No","1")
                .when().get("http://demo.guru99.com/V4/sinkministatement.php").getStatusCode();

                System.out.println("the status code is "+statusCode);

                given().when().get(url).then().assertThat().statusCode(200);
    }

    public static void getresponseheaders(){

        System.out .println("the headers of the response are "+ given().when().get(url).then().extract().headers());

    }

    public static void getresponsetime(){
        System.out.println("the response time is "+ given().when().get(url).timeIn(TimeUnit.MILLISECONDS) + "milliseconds");
    }

    public static void extractcontactype(){
        String contenttype=given().when().get(url).then().extract().contentType();
        System.out.println("the contact type is "+ contenttype);
        given().when().get(url).then().assertThat().contentType("text/html; charset=UTF-8");
    }

    public static void conetentype(){
        Headers headers= given().when().get(url).getHeaders();
        System.out.println("the content type is "+ headers.getValue("Content-Type"));

    }
    public static void verifyheader(){
        Headers headers= given().when().get(url).getHeaders();
        boolean headercheck=headers.getValue("Content-Length").equalsIgnoreCase("312");
        System.out.println("is the header Content-Length exists? "+headercheck);

    }

    public static void verifyresponsebody(){
        ResponseBody body = given().when().get(url).getBody();
        String bod=body.asString();
        boolean exp=bod.contains("TRANSACTION_ID");
        System.out.println("is the body contains TRANSACTION_ID? "+exp);
    }

       public static void main(String[] args) {
        getResponse();
        getresponsebody();
        getresponsestatus();
        getresponseheaders();
        getresponsetime();
        extractcontactype();
        conetentype();
        verifyheader();
        verifyresponsebody();

        }
    }
