package org.example;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

import javax.swing.plaf.PanelUI;
import java.util.concurrent.TimeUnit;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;


public class Restassured {

    final static String url="http://demo.guru99.com/V4/sinkministatement.php?CUSTOMER_ID=68195&PASSWORD=1234!&Account_No=1";

    public static String partialupadterequestBody = "{\n" +
            "  \"title\": \"sunt aut facere repellat provident occaecati excepturi optio reprehenderit\"\n" +
            "}";

    public static String newrequestBody = "{\n" +
            "  \"title\": \"foo\",\n" +
            "  \"body\": \"bar\",\n" +
            "  \"userId\": \"1\" \n}";


    public static String upadtefullrequestBody = "{\n" +
            "  \"title\": \"foo\",\n" +
            "  \"body\": \"baz\",\n" +
            "  \"userId\": \"1\",\n" +
            "  \"id\": \"1\" \n}";

    public static void getResponse(){
        given().when().get(url).then().log().all();
    }

    public static void getresponsebody(){
        given().when().get(url).then().log().body();
    }

    public static void getresponsestatus(){
        int statusCode=given()
                .queryParam("CUSTOMER_ID","68195")
                .queryParam("PASSWORD","1234")
                .queryParam("Account_No","1")
                .when().get("http://demo.guru99.com/V4/sinkministatement.php").getStatusCode();

                System.out.println("the status code is "+statusCode);

                given().when().get(url).then().assertThat().statusCode(200);
    }

    public static void getresponseheaders(){

        System.out .println("the headers of the response are "+ given().when().get(url).then().extract().headers());

    }

    public static void getresponsetime(){
        System.out.println("the response time is "+ given().when().get(url).timeIn(TimeUnit.MILLISECONDS) + "milliseconds");
    }

    public static void extractcontactype(){
        String contenttype=given().when().get(url).then().extract().contentType();
        System.out.println("the content type is "+ contenttype);
        given().when().get(url).then().assertThat().contentType("text/html; charset=UTF-8");
    }

    public static void conetentype(){
        Headers headers= given().when().get(url).getHeaders();
        System.out.println("the content type is "+ headers.getValue("Content-Type"));

    }
    public static void verifyheader(){
        Headers headers= given().when().get(url).getHeaders();
        boolean headercheck=headers.getValue("Content-Length").equalsIgnoreCase("312");
        System.out.println("is the header Content-Length equals 312? "+headercheck);

    }

    public static void verifyresponsebody(){
        ResponseBody body = given().when().get(url).getBody();
        String bod=body.asString();
        boolean exp=bod.contains("TRANSACTION_ID");
        System.out.println("is the body contains TRANSACTION_ID? "+exp);
    }


    public static void partialupadterequestbody() {


        Response response=given().body(partialupadterequestBody).contentType(ContentType.JSON).when().patch("https://jsonplaceholder.typicode.com/posts/1").then().extract().response();
        System.out.println("the response statuscode is "+ response.getStatusCode());
        System.out.println("the response content type is " + response.contentType());
        System.out.println("Response Body is " + response.getBody().asString());

    }

    public static void testpartialupadtedrequestbody(){
        given().body(partialupadterequestBody).when().patch("https://jsonplaceholder.typicode.com/posts/1");
        given().body(partialupadterequestBody).when().patch("https://jsonplaceholder.typicode.com/posts/1").then().body("title",equalTo("sunt aut facere repellat provident occaecati excepturi optio reprehenderit"));
        given().body(partialupadterequestBody).when().patch("https://jsonplaceholder.typicode.com/posts/1").then().contentType(" application/json; charset=utf-8");
        given().body(partialupadterequestBody).when().patch("https://jsonplaceholder.typicode.com/posts/1").then().log().headers();

    }


    public static void deleteaddedrequest(){

        int statuscode=given().when().delete("https://jsonplaceholder.typicode.com/posts/1").getStatusCode();
        System.out.println("the status code is " + statuscode);
    }


    public static void createnewrequest() {
        Response res=given().body(newrequestBody).contentType("application/json").when().post("https://jsonplaceholder.typicode.com/posts").then().extract().response();
        System.out.println("the response body is "+ res.getBody().asString());
        System.out.println(" the resposne status code is "+  res.getStatusCode());
        System.out.println(" the content type is " +res.contentType());
    }

    public static void upadtefullrequestbody(){
        Response rese=given().body(upadtefullrequestBody).contentType(ContentType.JSON).when().put("https://jsonplaceholder.typicode.com/posts/1").then().extract().response();
        System.out.println("the response statuscode is "+ rese.getStatusCode());
        System.out.println("the response content type is " + rese.contentType());
        System.out.println("Response Body is " + rese.getBody().asString());
    }



    public static void main(String[] args) {
        getResponse();
        getresponsebody();
        getresponsestatus();
        getresponseheaders();
        getresponsetime();
        extractcontactype();
        conetentype();
        verifyheader();
        verifyresponsebody();
        partialupadterequestbody();
        testpartialupadtedrequestbody();
        deleteaddedrequest();
        createnewrequest();
        upadtefullrequestbody();

        }
    }
